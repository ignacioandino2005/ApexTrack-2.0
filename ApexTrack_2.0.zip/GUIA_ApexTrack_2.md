# ApexTrack 2.0 — Guía de instalación y uso

## Qué cambió respecto a la V1.20
- **Ya no depende de Google Sheets ni de Apps Script.** Es una app web instalable (PWA): todo se guarda en el teléfono, funciona sin internet y se abre desde un ícono como cualquier app.
- **Botón Registrar (micrófono central):** escribís, dictás o grabás un audio ("almuerzo 6 empanadas… merienda… tomé la creatina"). La IA separa días y comidas, entiende correcciones ("80 no, 70 g"), agua, suplementos, gimnasio, peso y horas de estudio, y te muestra todo para revisar antes de guardar.
- **IA calibrada:** Gemini interpreta el mensaje y busca en internet marcas, productos y recetas nuevas; la app hace las cuentas (no la IA), controla que calorías y macros cierren, compara con tu historial y marca lo dudoso para corregirlo con un toque o con otro mensaje. Sin internet calcula con tu biblioteca (≈190 alimentos calibrados con tu historial + los tuyos) o lo guarda para analizarlo después.
- **Fechas arregladas:** la app usa la hora local de Argentina (la V1 usaba la hora UTC y después de las 21 h mostraba el día siguiente). Cambia sola a medianoche, tiene calendario propio (no el nativo), tira de semana deslizable y botón "Volver a hoy".
- Diario semanal/mensual con gráficos, Progreso (peso con tendencia, medidas, de dónde vienen tus calorías, alimentos que más aportan), Gimnasio con rutinas, series, temporizador de descanso, sugerencia de progresión y 1RM estimado.
- **Excel:** Ajustes → Exportar a Excel genera una planilla mejorada (Resumen, Diario con colores de meta, Comidas por día desplegables, Detalle filtrable, Gimnasio, Progreso corporal, Hábitos, Mis alimentos). Y Ajustes → Importar planilla anterior trae todo tu historial de la V1.
- Modo oscuro, menús propios (sin desplegables nativos feos), botón atrás de Android cierra ventanas, atajos en el ícono ("Registrar" y "Sumar agua").

## 1. Publicarla (una sola vez, gratis) — GitHub Pages
1. Creá una cuenta en github.com (si no tenés).
2. Botón **New repository** → nombre `apextrack` → Public → Create.
3. En el repositorio: **Add file → Upload files** y arrastrá **el contenido de la carpeta `app`** (index.html, sw.js, manifest.webmanifest y las carpetas css, js, fonts, icons, vendor). Commit.
4. **Settings → Pages** → Source: *Deploy from a branch* → Branch: `main` / `(root)` → Save.
5. En 1–2 minutos queda en `https://TU_USUARIO.github.io/apextrack/`.

Alternativa sin cuenta de GitHub: netlify.com/drop → arrastrar la carpeta `app`.

## 2. Instalarla en el Android
1. Abrí la dirección en **Chrome**.
2. Menú ⋮ → **Instalar app** (o "Agregar a pantalla principal").
3. Abrila desde el ícono. Mantener apretado el ícono muestra los atajos.

## 3. Clave de la IA (gratis)
1. Entrá a **aistudio.google.com/apikey** con la cuenta de Google que quieras usar.
2. **Create API key** → copiala.
3. En la app: ⚙️ Ajustes → Inteligencia artificial → pegala → **Probar conexión** → Guardar.
- La clave queda **solo en tu teléfono** (no se sube a ningún lado, no está en el código ni en las copias de seguridad).
- **Importante:** las dos claves que estaban escritas en el código de la V1.20 quedaron expuestas. Borralas en AI Studio y creá una nueva.
- Precisión: *Equilibrada* (recomendada), *Rápida* o *Máxima* (modelo Pro, más lento). Modelo en *Automático*: si Google retira un modelo, la app usa el siguiente (eso fue lo que rompió la IA de la V1).

## 4. Pasar tu historial de la V1
1. En Google Sheets: Archivo → Descargar → Microsoft Excel (.xlsx).
2. En la app: Ajustes → **Importar planilla anterior** → elegí el archivo → Importar.
   (Probado con tu planilla: 266 alimentos de 16 días, pesajes, gimnasio y hábitos.)

## 5. Probar la IA
Ajustes → **Probar la IA** tiene 15 mensajes de prueba (tus 3 textos + 12 nuevos: marcas, comida rápida, recetas, porciones ambiguas, agua total, días anteriores, dictado sin puntuación…) con el resultado esperado de cada uno. **No guarda nada en tu registro.** Tocá "Probar todas" y después "Copiar informe" para pegarlo en el chat si algo falla. También podés analizar un mensaje propio sin guardarlo.

## 6. Copias de seguridad
Los datos viven en el teléfono. Ajustes → **Copia de seguridad** genera un archivo .json (guardalo en Drive). La app te lo recuerda cada 2 semanas. Para pasar a otro teléfono: Ajustes → Restaurar copia.

## 7. Actualizaciones
Cuando subas una versión nueva a GitHub, la app muestra "Hay una versión nueva" → Actualizar. Tus datos no se tocan.
