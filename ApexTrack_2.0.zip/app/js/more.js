// ApexTrack — Diario, Progreso, Gimnasio y Ajustes.
import {
  todayISO, addDays, addMonths, weekStart, monthStart, dateRange, fmt, fmtDayLong, fmtDayShort, fmtMonthYear, fmtDM, relativeDayLabel,
  esc, cap, round1, round0, parseNum, vibrate, deepClone, uid, norm, parseISO, MESES, daysBetween, slug,
} from './util.js';
import * as store from './store.js';
import * as AI from './ai.js';
import { unitLabel, canonUnit, UNITS } from './foods.js';
import { icon } from './icons.js';
import { openSheet, toast, confirmDialog, pickOption, pickDate, promptText, formSheet, setBusy } from './ui.js';
import { weekBars, weightLine, simpleLine } from './charts.js';
import { ui, go, setDate, render, pickMoment, prettyModel, applyTheme, dayMarks } from './app.js';

const METRICS = {
  kcal: { label: 'Kcal', unit: 'kcal', dec: 0, goal: (g) => g.kcal, val: (d) => store.dayTotals(d).kcal },
  p: { label: 'Proteína', unit: 'g', dec: 0, goal: (g) => g.p, val: (d) => store.dayTotals(d).p },
  c: { label: 'Carbos', unit: 'g', dec: 0, goal: (g) => g.c, val: (d) => store.dayTotals(d).c },
  f: { label: 'Grasas', unit: 'g', dec: 0, goal: (g) => g.f, val: (d) => store.dayTotals(d).f },
  water: { label: 'Agua', unit: 'L', dec: 1, goal: (g) => (g.waterMl || 2500) / 1000, val: (d) => (store.day(d).water || 0) / 1000 },
};
const GYM_LABEL = { fui: 'Gimnasio', no_fui: 'No fue al gym', descanso: 'Descanso' };

// ===========================================================================
// DIARIO
// ===========================================================================
function dayCard(d) {
  const g = store.goals();
  const t = store.dayTotals(d);
  const rec = store.day(d);
  const pct = Math.min(100, g.kcal ? (t.kcal / g.kcal) * 100 : 0);
  const mk = dayMarks(d);
  const rel = relativeDayLabel(d);
  const title = ['Hoy', 'Ayer', 'Anteayer'].includes(rel) ? `${rel} · ${fmtDayShort(d)}` : cap(fmtDayShort(d));
  return `<button class="day-card" data-act="dia-open" data-date="${d}">
    <h4>${esc(title)}</h4>
    <span class="dc-k">${fmt(t.kcal)} <small>/ ${fmt(g.kcal)} kcal</small></span>
    <span class="dc-bar"><i style="width:${pct}%;${mk === 'meta' ? 'background:var(--good)' : ''}"></i></span>
    <span class="dc-sub"><span>P ${fmt(t.p)} g</span><span>C ${fmt(t.c)} g</span><span>G ${fmt(t.f)} g</span>${rec.water ? `<span>${icon('drop', 13)} ${fmt(rec.water / 1000, 1)} L</span>` : ''}${rec.gym ? `<span>${icon('dumbbell', 13)} ${GYM_LABEL[rec.gym]}</span>` : ''}${store.bodyOn(d)?.weight ? `<span>${icon('scale', 13)} ${fmt(store.bodyOn(d).weight, 1)} kg</span>` : ''}</span>
  </button>`;
}

export function renderDiario() {
  const D = ui.diary;
  const today = todayISO();
  const g = store.goals();
  const M = METRICS[D.metric] || METRICS.kcal;
  const modeSeg = `<div class="seg-ctl" style="margin-bottom:14px">${[['semana', 'Semana'], ['mes', 'Mes']].map(([k, l]) => `<button class="${D.mode === k ? 'on' : ''}" data-act="dia-mode" data-v="${k}">${l}</button>`).join('')}</div>`;
  const metricChips = `<div class="chip-row metric" style="margin-bottom:10px">${Object.entries(METRICS).map(([k, m]) => `<button class="chip ${D.metric === k ? 'on' : ''}" data-act="dia-metric" data-v="${k}">${m.label}</button>`).join('')}</div>`;

  if (D.mode === 'mes') {
    const ms = monthStart(D.month || today);
    const me = addDays(addMonths(ms, 1), -1);
    const days = dateRange(ms, me > today ? today : me);
    const logged = days.filter((d) => store.entriesOn(d).length);
    const avgK = logged.length ? logged.reduce((a, d) => a + store.dayTotals(d).kcal, 0) / logged.length : 0;
    const avgP = logged.length ? logged.reduce((a, d) => a + store.dayTotals(d).p, 0) / logged.length : 0;
    const meta = logged.filter((d) => dayMarks(d) === 'meta').length;
    const gymN = days.filter((d) => store.day(d).gym === 'fui').length;
    const lead = (parseISO(ms).getDay() + 6) % 7;
    const cells = [];
    for (let i = 0; i < lead; i++) cells.push('<span></span>');
    for (const d of dateRange(ms, me)) {
      const mk = dayMarks(d);
      cells.push(`<button class="cal-d ${d === today ? 'tod' : ''} ${d === D.sel ? 'sel' : ''}" data-act="dia-open" data-date="${d}" ${d > today ? 'disabled' : ''}><span>${parseISO(d).getDate()}</span>${mk ? `<i class="dot ${mk}"></i>` : ''}</button>`);
    }
    return `<h1 class="view-title">Diario</h1>${modeSeg}
      <section class="panel">
        <div class="chart-nav">
          <button class="icon-btn" data-act="dia-month" data-d="-1" aria-label="Mes anterior">${icon('left')}</button>
          <strong>${cap(fmtMonthYear(ms))}</strong>
          <button class="icon-btn" data-act="dia-month" data-d="1" aria-label="Mes siguiente" ${addMonths(ms, 1) > today ? 'disabled' : ''}>${icon('right')}</button>
        </div>
        <div class="cal"><div class="cal-w">${['L', 'M', 'M', 'J', 'V', 'S', 'D'].map((x) => `<span>${x}</span>`).join('')}</div><div class="cal-g">${cells.join('')}</div>
        <div class="cal-legend"><span><i class="dot meta"></i>en meta</span><span><i class="dot cerca"></i>cerca</span><span><i class="dot bajo"></i>bajo</span></div></div>
      </section>
      <div class="stat-grid" style="margin-top:12px">
        <div class="stat"><small>Promedio kcal</small><b>${logged.length ? fmt(avgK) : '–'}</b><span>meta ${fmt(g.kcal)}</span></div>
        <div class="stat"><small>Promedio proteína</small><b>${logged.length ? fmt(avgP) + ' g' : '–'}</b><span>meta ${fmt(g.p)} g</span></div>
        <div class="stat"><small>Días en meta</small><b>${meta}<span style="font-size:15px"> / ${logged.length}</span></b><span>días con registro</span></div>
        <div class="stat"><small>Gimnasio</small><b>${gymN}</b><span>días este mes</span></div>
      </div>
      <section class="section"><div class="section-head"><h3>Días registrados</h3></div>
        ${logged.length ? logged.slice().reverse().map(dayCard).join('') : '<div class="empty"><strong>Sin registros este mes</strong>Los días que registres aparecen acá.</div>'}
      </section>`;
  }

  // Semana
  const ws = D.week || weekStart(today);
  const days = dateRange(ws, addDays(ws, 6));
  if (!days.includes(D.sel)) D.sel = days.includes(today) ? today : days.find((d) => store.entriesOn(d).length) || ws;
  const data = days.map((d) => ({ date: d, value: d > today ? 0 : M.val(d) }));
  const chart = weekBars({ days: data, goal: M.goal(g), sel: D.sel, unit: M.unit, dec: M.dec, today });
  const selT = store.dayTotals(D.sel);
  const logged = days.filter((d) => d <= today && store.entriesOn(d).length);
  const avg = (k) => (logged.length ? logged.reduce((a, d) => a + store.dayTotals(d)[k], 0) / logged.length : 0);
  const avgW = days.filter((d) => d <= today && store.day(d).water).reduce((a, d, _, arr) => a + store.day(d).water / arr.length, 0);
  const gymN = store.gymCountWeek(ws);
  const endW = addDays(ws, 6);
  const rangeLabel = ws.slice(0, 7) === endW.slice(0, 7) ? `${parseISO(ws).getDate()} al ${parseISO(endW).getDate()} de ${MESES[parseISO(ws).getMonth()]}` : `${fmtDM(ws)} al ${fmtDM(endW)}`;
  const isCur = ws === weekStart(today);
  return `<h1 class="view-title">Diario</h1>${modeSeg}
    <section class="panel">
      <div class="chart-nav">
        <button class="icon-btn" data-act="dia-week" data-d="-1" aria-label="Semana anterior">${icon('left')}</button>
        <button class="date-label" data-act="dia-pick" style="justify-content:center"><span><strong>${isCur ? 'Esta semana' : esc(rangeLabel)}</strong>${isCur ? `<small>${esc(rangeLabel)}</small>` : ''}</span>${icon('down', 16)}</button>
        <button class="icon-btn" data-act="dia-week" data-d="1" aria-label="Semana siguiente" ${addDays(ws, 7) > today ? 'disabled' : ''}>${icon('right')}</button>
      </div>
      ${metricChips}
      <div class="chart-box" data-swipe="diary">${chart}</div>
      <div class="readout"><span>${esc(cap(fmtDayLong(D.sel)))}</span><span><b>${fmt(M.val(D.sel), M.dec)} ${M.unit}</b>${D.sel <= today && store.entriesOn(D.sel).length ? ` · <button class="link" data-act="dia-open" data-date="${D.sel}">Ver día</button>` : ''}</span></div>
      ${D.metric === 'kcal' && selT.items ? `<div class="note">P ${fmt(selT.p)} g · C ${fmt(selT.c)} g · G ${fmt(selT.f)} g</div>` : ''}
    </section>
    <div class="stat-grid" style="margin-top:12px">
      <div class="stat"><small>Promedio kcal</small><b>${logged.length ? fmt(avg('kcal')) : '–'}</b><span>${logged.length} ${logged.length === 1 ? 'día' : 'días'} con registro</span></div>
      <div class="stat"><small>Promedio proteína</small><b>${logged.length ? fmt(avg('p')) + ' g' : '–'}</b><span>meta ${fmt(g.p)} g</span></div>
      <div class="stat"><small>Agua promedio</small><b>${avgW ? fmt(avgW / 1000, 1) + ' L' : '–'}</b><span>meta ${fmt((g.waterMl || 2500) / 1000, 1)} L</span></div>
      <div class="stat"><small>Gimnasio</small><b>${gymN}<span style="font-size:15px"> / ${g.gymDays || 4}</span></b><span>días esta semana</span></div>
    </div>
    <section class="section"><div class="section-head"><h3>Días</h3></div>
      ${days.filter((d) => d <= today).reverse().map(dayCard).join('')}
    </section>`;
}

// ===========================================================================
// PROGRESO
// ===========================================================================
export function renderProgreso() {
  const P = ui.prog;
  const today = todayISO();
  const S = store.S();
  const g = store.goals();
  const from = P.range === 'todo' ? '0000' : addDays(today, -(P.range - 1));
  const trend = store.weightTrend().filter((p) => p.date >= from);
  const goalW = S.settings.profile.goalWeight || null;
  const rangeSeg = `<div class="seg-ctl" style="margin-bottom:14px">${[[30, '30 días'], [90, '3 meses'], [365, '1 año'], ['todo', 'Todo']].map(([k, l]) => `<button class="${P.range === k ? 'on' : ''}" data-act="prog-range" data-v="${k}">${l}</button>`).join('')}</div>`;
  let weightHtml;
  if (trend.length) {
    const last = trend[trend.length - 1];
    const first = trend[0];
    const span = Math.max(1, daysBetween(first.date, last.date));
    const rate = trend.length > 1 ? ((last.trend - first.trend) / span) * 7 : 0;
    weightHtml = `<section class="panel">
      <div class="section-head" style="margin:0 0 6px"><h3>Peso</h3><button class="link" data-act="weight-today">Registrar</button></div>
      <div class="hero-row" style="margin-bottom:6px"><div><div class="hero-num" style="font-size:38px">${fmt(last.kg, 1)}<span style="font-size:17px;font-weight:600"> kg</span></div><div class="hero-goal">último pesaje · ${esc(relativeDayLabel(last.date).toLowerCase())}</div></div>
        <div class="hero-left"><b>${trend.length > 1 ? (rate >= 0 ? '+' : '−') + fmt(Math.abs(rate), 2) : '–'}</b><span>kg por semana (tendencia)</span></div></div>
      <div class="chart-box">${weightLine({ points: trend, goal: goalW })}</div>
      <div class="legend"><span><i class="k-dot"></i>Pesajes</span><span><i class="k-line"></i>Tendencia ${fmt(last.trend, 1)} kg</span></div>
    </section>`;
  } else {
    weightHtml = `<section class="panel"><div class="empty" style="padding:18px 6px"><strong>Todavía no hay pesajes</strong>Pesate en ayunas y registralo: la app calcula tu tendencia real sin el ruido diario.<div style="margin-top:12px"><button class="btn primary" data-act="weight-today">${icon('scale', 18)} Registrar peso</button></div></div></section>`;
  }
  const days = P.range === 'todo' ? Math.max(1, daysBetween(store.firstDate(), today) + 1) : P.range;
  const avg = store.averages(days);
  const kP = avg ? avg.p * 4 : 0; const kC = avg ? avg.c * 4 : 0; const kF = avg ? avg.f * 9 : 0; const kT = kP + kC + kF || 1;
  const split = avg ? `<section class="panel" style="margin-top:12px">
      <h3 class="sub-h" style="margin-top:0">De dónde vienen tus calorías</h3>
      <div class="share-bar"><i style="flex:${kP};background:var(--prot)"></i><i style="flex:${kC};background:var(--carb)"></i><i style="flex:${kF};background:var(--fat)"></i></div>
      <div class="legend" style="flex-wrap:wrap"><span><i class="k-dot" style="background:var(--prot)"></i>Proteína ${fmt((kP / kT) * 100)} %</span><span><i class="k-dot" style="background:var(--carb)"></i>Carbos ${fmt((kC / kT) * 100)} %</span><span><i class="k-dot" style="background:var(--fat)"></i>Grasas ${fmt((kF / kT) * 100)} %</span></div>
      <p class="note">Promedio por día: ${fmt(avg.p)} g de proteína (${fmt(avg.p / (store.latestWeight()?.kg || 60), 1)} g por kg), ${fmt(avg.c)} g de carbos, ${fmt(avg.f)} g de grasas, ${fmt(avg.s)} g de azúcares.</p>
    </section>` : '';
  const share = store.byMomentShare(days);
  const totK = Object.values(share).reduce((a, x) => a + x.kcal, 0) || 1;
  const moments = Object.entries(share).sort((a, b) => store.momentIndex(a[0]) - store.momentIndex(b[0]));
  const momentsHtml = moments.length ? `<section class="panel" style="margin-top:12px"><h3 class="sub-h" style="margin-top:0">Calorías por comida</h3><div class="top-list">${moments.map(([m, x]) => `<div class="top-row"><span>${esc(store.momentName(m))}</span><span>${fmt((x.kcal / totK) * 100)} % · ${fmt(x.kcal / (avg?.days || 1))} kcal/día</span></div>`).join('')}</div></section>` : '';
  const top = store.topFoods(days);
  const topHtml = top.length ? `<section class="panel" style="margin-top:12px"><h3 class="sub-h" style="margin-top:0">Lo que más calorías te aporta</h3><div class="top-list">${top.map((f) => `<div class="top-row"><span>${esc(f.name)} <small class="muted">×${f.n}</small></span><span>${fmt(f.kcal)} kcal</span></div>`).join('')}</div></section>` : '';
  const lastBody = [...S.body].reverse().find((b) => b.waist || b.chest || b.arm || b.thigh || b.calf || b.fat);
  const meas = [['chest', 'Pecho'], ['waist', 'Cintura'], ['arm', 'Brazo'], ['thigh', 'Muslo'], ['calf', 'Gemelos'], ['fat', '% grasa']];
  const measHtml = `<section class="section"><div class="section-head"><h3>Medidas</h3><button class="link" data-act="measures">${lastBody ? 'Actualizar' : 'Agregar'}</button></div>
    ${lastBody ? `<div class="panel"><div class="note" style="margin:0 0 8px">Última medición: ${esc(cap(fmtDayLong(lastBody.date)))}</div><div class="top-list">${meas.filter(([k]) => lastBody[k] != null).map(([k, l]) => {
      const prev = [...S.body].reverse().find((b) => b.date < lastBody.date && b[k] != null);
      const diff = prev ? lastBody[k] - prev[k] : null;
      return `<div class="top-row"><span>${l}</span><span>${fmt(lastBody[k], 1)} ${k === 'fat' ? '%' : 'cm'}${diff != null && Math.abs(diff) >= 0.05 ? ` <small class="muted">(${diff > 0 ? '+' : '−'}${fmt(Math.abs(diff), 1)})</small>` : ''}</span></div>`;
    }).join('')}</div></div>` : '<div class="empty"><strong>Sin medidas</strong>Registrá cintura, brazo y otras medidas cada 2 a 4 semanas.</div>'}
  </section>`;
  const st = store.streak();
  const avg7 = store.averages(7);
  const stats = `<div class="stat-grid" style="margin-top:12px">
      <div class="stat"><small>Racha de registro</small><b>${st}</b><span>${st === 1 ? 'día seguido' : 'días seguidos'}</span></div>
      <div class="stat"><small>Kcal promedio (7 d)</small><b>${avg7 ? fmt(avg7.kcal) : '–'}</b><span>meta ${fmt(g.kcal)}</span></div>
      <div class="stat"><small>Días en meta de kcal</small><b>${avg ? avg.kcalHit : 0}<span style="font-size:15px"> / ${avg ? avg.days : 0}</span></b><span>en el período</span></div>
      <div class="stat"><small>Días en meta de proteína</small><b>${avg ? avg.protHit : 0}<span style="font-size:15px"> / ${avg ? avg.days : 0}</span></b><span>en el período</span></div>
    </div>`;
  return `<h1 class="view-title">Progreso</h1>${rangeSeg}${weightHtml}${stats}${split}${momentsHtml}${topHtml}${measHtml}`;
}

async function openMeasures() {
  const last = [...store.S().body].reverse().find((b) => b.waist || b.chest) || {};
  const r = await formSheet({
    title: 'Medidas corporales', intro: 'Medí siempre en el mismo lugar y a la misma hora. Dejá vacío lo que no midas.',
    fields: [
      { key: 'date', label: 'Fecha', type: 'date', value: todayISO(), full: true },
      { key: 'chest', label: 'Pecho', type: 'number', suffix: 'cm', placeholder: last.chest ? fmt(last.chest, 1) : '' },
      { key: 'waist', label: 'Cintura', type: 'number', suffix: 'cm', placeholder: last.waist ? fmt(last.waist, 1) : '' },
      { key: 'arm', label: 'Brazo', type: 'number', suffix: 'cm', placeholder: last.arm ? fmt(last.arm, 1) : '' },
      { key: 'thigh', label: 'Muslo', type: 'number', suffix: 'cm', placeholder: last.thigh ? fmt(last.thigh, 1) : '' },
      { key: 'calf', label: 'Gemelos', type: 'number', suffix: 'cm', placeholder: last.calf ? fmt(last.calf, 1) : '' },
      { key: 'fat', label: 'Grasa corporal', type: 'number', suffix: '%', placeholder: last.fat ? fmt(last.fat, 1) : '' },
      { key: 'note', label: 'Nota', type: 'text', full: true },
    ],
  });
  if (!r) return;
  const f = {};
  for (const k of ['chest', 'waist', 'arm', 'thigh', 'calf', 'fat']) if (Number.isFinite(r[k])) f[k] = round1(r[k]);
  if (r.note) f.note = r.note;
  if (!Object.keys(f).length) { toast('No cargaste ninguna medida'); return; }
  store.upsertBody(r.date, f); store.commit('medidas');
  toast('Medidas guardadas');
}

// ===========================================================================
// GIMNASIO
// ===========================================================================
let rest = null; // { end, total, label }
let restEl = null;
const elapsed = (t0) => { const s = Math.max(0, Math.floor((Date.now() - t0) / 1000)); const h = Math.floor(s / 3600); const m = Math.floor((s % 3600) / 60); return h ? `${h} h ${String(m).padStart(2, '0')} min` : `${m} min`; };

export function renderGym() {
  const S = store.S();
  const A = S.gym.active;
  if (A) return renderActiveSession(A);
  const g = store.goals();
  const today = todayISO();
  const ws = weekStart(today);
  const wdays = dateRange(ws, addDays(ws, 6));
  const done = wdays.filter((d) => store.day(d).gym === 'fui').length;
  const dots = wdays.map((d) => `<i class="${store.day(d).gym === 'fui' ? 'on' : ''}" title="${esc(fmtDayShort(d))}"></i>`).join('');
  const nextR = suggestRoutine();
  const routines = store.routines().map((r) => {
    const last = store.sessionsOf(r.id)[0];
    return `<button class="routine-card" data-act="gym-start" data-id="${r.id}">
      <span class="grow"><h4>${esc(r.name)}${nextR === r.id ? ' <span class="badge web">sigue</span>' : ''}</h4><small>${r.exercises.length} ejercicios · ${last ? 'última vez ' + esc(relativeDayLabel(last.date).toLowerCase()) : 'sin sesiones'}</small></span>
      ${icon('play', 22)}</button>`;
  }).join('');
  const sessions = S.gym.sessions.slice().sort((a, b) => b.date.localeCompare(a.date) || (b.startedAt || 0) - (a.startedAt || 0)).slice(0, 12);
  const hist = sessions.map((s) => {
    const sets = (s.exercises || []).reduce((a, e) => a + (e.sets || []).filter((x) => x.kg || x.reps).length, 0);
    const vol = (s.exercises || []).reduce((a, e) => a + (e.sets || []).reduce((b, x) => b + (Number(x.kg) || 0) * (Number(x.reps) || 0), 0), 0);
    return `<button class="day-card" data-act="gym-session" data-id="${s.id}"><h4>${esc(s.routineName || store.routines().find((r) => r.id === s.routineId)?.name || 'Sesión')}</h4><span class="dc-k">${esc(cap(fmtDayShort(s.date)))}</span><span class="dc-sub"><span>${(s.exercises || []).length} ejercicios</span><span>${sets} series</span>${vol ? `<span>${fmt(vol)} kg de volumen</span>` : ''}</span></button>`;
  }).join('');
  return `<h1 class="view-title">Gimnasio</h1>
    <section class="panel">
      <div class="kv"><span>${icon('dumbbell', 18)}Esta semana</span><b>${done} / ${g.gymDays || 4} días</b></div>
      <div class="week-dots" style="margin-top:10px">${dots}</div>
    </section>
    <section class="section"><div class="section-head"><h3>Empezar rutina</h3><button class="link" data-act="gym-routines">Editar rutinas</button></div>
      ${routines || '<div class="empty"><strong>Sin rutinas</strong>Creá tu primera rutina.</div>'}
      <button class="btn ghost" style="width:100%;margin-top:10px" data-act="gym-start-free">${icon('plus', 18)} Sesión libre</button>
    </section>
    <section class="section"><div class="section-head"><h3>Historial</h3>${S.gym.sessions.length ? '<button class="link" data-act="gym-progress">Progreso por ejercicio</button>' : ''}</div>
      ${hist || '<div class="empty"><strong>Todavía no hay sesiones</strong>Al terminar una rutina queda guardada acá, con tus pesos para la próxima.</div>'}
    </section>`;
}

function suggestRoutine() {
  const rs = store.routines();
  if (!rs.length) return null;
  const last = store.sessionsOf()[0];
  if (!last) return rs[0].id;
  const i = rs.findIndex((r) => r.id === last.routineId);
  return i < 0 ? rs[0].id : rs[(i + 1) % rs.length].id;
}

function renderActiveSession(A) {
  const ex = A.exercises.map((e, ei) => {
    const last = store.lastSetsFor(e.name, A.date);
    const hint = store.progressionHint(e, last);
    const lastTxt = last ? last.sets.map((x) => `${fmt(x.kg, 1)}×${x.reps}`).join(' · ') : '';
    const rows = e.sets.map((st, si) => `
      <div class="set-row">
        <span>${si + 1}</span>
        <input class="input set-in" inputmode="decimal" data-ex="${ei}" data-set="${si}" data-k="kg" value="${st.kg === '' || st.kg == null ? '' : String(st.kg).replace('.', ',')}" placeholder="${last?.sets[si] ? String(last.sets[si].kg).replace('.', ',') : 'kg'}" aria-label="Kilos serie ${si + 1}">
        <input class="input set-in" inputmode="numeric" data-ex="${ei}" data-set="${si}" data-k="reps" value="${st.reps === '' || st.reps == null ? '' : st.reps}" placeholder="${last?.sets[si] ? last.sets[si].reps : 'reps'}" aria-label="Repeticiones serie ${si + 1}">
        <button class="set-ok ${st.done ? 'on' : ''}" data-act="set-done" data-ex="${ei}" data-set="${si}" aria-label="Serie hecha">${icon('check', 20)}</button>
      </div>`).join('');
    return `<article class="ex-card">
      <div class="ex-head"><div class="grow"><h4>${esc(e.name)}</h4><div class="ex-meta">${e.target ? esc(e.target) + ' reps · ' : ''}descanso ${fmtRest(e.rest || 90)}${lastTxt ? ` · antes: ${esc(lastTxt)}` : ''}</div></div>
        <button class="icon-btn" data-act="ex-menu" data-ex="${ei}" aria-label="Opciones del ejercicio">${icon('more')}</button></div>
      ${hint ? `<div class="ex-hint">${icon('bolt', 14)} ${esc(hint)}</div>` : ''}
      <div class="sets"><div class="set-labels"><span>#</span><span>Kg</span><span>Reps</span><span></span></div>${rows}</div>
      <button class="btn small ghost" style="margin-top:8px" data-act="set-add" data-ex="${ei}">${icon('plus', 16)} Serie</button>
    </article>`;
  }).join('');
  const nDone = A.exercises.reduce((a, e) => a + e.sets.filter((s) => s.done).length, 0);
  const nAll = A.exercises.reduce((a, e) => a + e.sets.length, 0);
  return `<div class="section-head" style="margin-top:4px"><div><h1 class="view-title" style="margin:0">${esc(A.routineName)}</h1><div class="muted" style="font-size:14px"><span id="gym-elapsed">${elapsed(A.startedAt)}</span> · ${nDone}/${nAll} series · ${esc(relativeDayLabel(A.date))}</div></div>
      <button class="btn small ghost" data-act="gym-cancel">Descartar</button></div>
    <div style="margin-top:12px">${ex}</div>
    <button class="btn ghost" style="width:100%;margin-top:10px" data-act="ex-add">${icon('plus', 18)} Agregar ejercicio</button>
    <button class="btn primary" style="width:100%;margin-top:10px" data-act="gym-finish">${icon('check', 20)} Terminar y guardar</button>
    <div style="height:70px"></div>`;
}

function startSession(routine) {
  const S = store.S();
  const date = todayISO();
  const exercises = (routine ? routine.exercises : []).map((e) => {
    const last = store.lastSetsFor(e.name, date);
    const n = Math.max(1, Number(e.sets) || 3);
    return { name: e.name, target: e.reps, rest: e.rest || 90, sets: Array.from({ length: n }, (_, i) => ({ kg: last?.sets[i]?.kg ?? last?.sets[last.sets.length - 1]?.kg ?? '', reps: '', done: false })) };
  });
  S.gym.active = { id: uid('s'), date, routineId: routine?.id || null, routineName: routine?.name || 'Sesión libre', startedAt: Date.now(), exercises };
  store.commit('gym');
  window.scrollTo(0, 0);
}

function finishSession() {
  const S = store.S();
  const A = S.gym.active;
  if (!A) return;
  const clean = { ...A, done: true, finishedAt: Date.now() };
  clean.exercises = A.exercises.map((e) => ({ name: e.name, target: e.target, note: e.note || '', sets: e.sets.filter((s) => s.done || (s.kg !== '' && s.reps !== '' && s.reps != null)).map((s) => ({ kg: Number(String(s.kg).replace(',', '.')) || 0, reps: Number(s.reps) || 0 })) })).filter((e) => e.sets.length);
  if (!clean.exercises.length) { toast('Marcá al menos una serie con kilos y repeticiones', { kind: 'error' }); return; }
  S.gym.sessions.push(clean);
  S.gym.active = null;
  store.setGym(clean.date, 'fui', clean.routineName);
  stopRest();
  store.commit('gym');
  const vol = clean.exercises.reduce((a, e) => a + e.sets.reduce((b, s) => b + s.kg * s.reps, 0), 0);
  toast(`Sesión guardada · ${fmt(vol)} kg de volumen`);
}

function startRest(sec, label = '') {
  rest = { end: Date.now() + sec * 1000, total: sec, label };
  gymTimerTick();
}
function stopRest() { rest = null; if (restEl) { restEl.remove(); restEl = null; } }

export function gymTimerTick() {
  const el = document.getElementById('gym-elapsed');
  const A = store.S().gym?.active;
  if (el && A) el.textContent = elapsed(A.startedAt);
  if (!rest) return;
  const left = Math.ceil((rest.end - Date.now()) / 1000);
  if (!restEl) {
    restEl = document.createElement('div');
    restEl.className = 'timer-pill';
    restEl.innerHTML = `${icon('timer', 18)}<b></b><button data-t="-15" aria-label="Restar 15 segundos">${icon('minus', 18)}</button><button data-t="15" aria-label="Sumar 15 segundos">${icon('plus', 18)}</button><button data-t="x" aria-label="Cerrar temporizador">${icon('x', 18)}</button>`;
    restEl.addEventListener('click', (e) => {
      const b = e.target.closest('[data-t]');
      if (!b || !rest) return;
      if (b.dataset.t === 'x') { stopRest(); return; }
      rest.end += Number(b.dataset.t) * 1000; restEl.classList.remove('done'); gymTimerTick();
    });
    document.body.appendChild(restEl);
  }
  const b = restEl.querySelector('b');
  if (left > 0) {
    b.textContent = `${Math.floor(left / 60)}:${String(left % 60).padStart(2, '0')}`;
    restEl.classList.remove('done');
  } else {
    if (!restEl.classList.contains('done')) { restEl.classList.add('done'); vibrate([180, 90, 180]); }
    b.textContent = '¡Listo!';
    if (left < -5) stopRest();
  }
}

// los campos de las series se guardan sin redibujar
document.addEventListener('input', (e) => {
  const inp = e.target.closest?.('.set-in');
  if (!inp) return;
  const A = store.S().gym.active;
  if (!A) return;
  const st = A.exercises[Number(inp.dataset.ex)]?.sets[Number(inp.dataset.set)];
  if (!st) return;
  const v = inp.value.trim();
  st[inp.dataset.k] = v === '' ? '' : (inp.dataset.k === 'reps' ? parseInt(v, 10) || '' : v.replace(',', '.'));
  store.save();
});

async function openRoutines() {
  const draw = () => `<div class="opt-list">${store.routines().map((r) => `<button class="opt" data-id="${r.id}"><span class="opt-main">${icon('list', 20)}<span>${esc(r.name)}<small>${r.exercises.length} ejercicios</small></span></span>${icon('right', 18)}</button>`).join('')}
    <button class="opt" data-new="1"><span class="opt-main">${icon('plus', 20)}<span>Nueva rutina</span></span></button></div>`;
  const s = openSheet({ title: 'Rutinas', body: draw() });
  s.body.addEventListener('click', async (e) => {
    const b = e.target.closest('.opt');
    if (!b) return;
    let r;
    if (b.dataset.new) {
      const name = await promptText({ title: 'Nueva rutina', label: 'Nombre', placeholder: 'Ej.: Torso C' });
      if (!name) return;
      r = { id: slug(name) + '_' + uid('').slice(-4), name, exercises: [] };
      store.S().gym.routines.push(r); store.commit('rutina');
    } else r = store.routines().find((x) => x.id === b.dataset.id);
    if (r) { await editRoutine(r); s.setBody(draw()); }
  });
}

function editRoutine(r) {
  const draw = () => `
    <label class="field"><span>Nombre</span><input class="input" data-rname value="${esc(r.name)}"></label>
    <div class="edit-list" style="margin-top:10px">${r.exercises.map((e, i) => `
      <div class="er" style="flex-wrap:wrap">
        <input class="input" style="flex:1 1 100%" data-i="${i}" data-k="name" value="${esc(e.name)}" aria-label="Ejercicio">
        <label class="field" style="flex:1"><span>Series</span><input class="input" inputmode="numeric" data-i="${i}" data-k="sets" value="${e.sets}"></label>
        <label class="field" style="flex:1"><span>Reps</span><input class="input" data-i="${i}" data-k="reps" value="${esc(e.reps)}"></label>
        <label class="field" style="flex:1"><span>Pausa (s)</span><input class="input" inputmode="numeric" data-i="${i}" data-k="rest" value="${e.rest}"></label>
        <div style="display:flex;gap:4px;align-self:flex-end">
          <button class="icon-btn" data-mv="${i}" data-d="-1" aria-label="Subir" ${i === 0 ? 'disabled' : ''}>${icon('up', 18)}</button>
          <button class="icon-btn" data-mv="${i}" data-d="1" aria-label="Bajar" ${i === r.exercises.length - 1 ? 'disabled' : ''}>${icon('down', 18)}</button>
          <button class="icon-btn" data-del="${i}" aria-label="Quitar">${icon('trash', 18)}</button>
        </div>
      </div>`).join('')}</div>
    <button class="btn ghost" style="width:100%;margin-top:12px" data-add>${icon('plus', 18)} Agregar ejercicio</button>`;
  const s = openSheet({ title: 'Editar rutina', full: true, body: draw(), footer: `<button class="btn ghost danger-text" data-delr>${icon('trash', 18)} Borrar rutina</button><button class="btn primary" data-ok>Listo</button>` });
  const read = () => {
    const n = s.body.querySelector('[data-rname]'); if (n && n.value.trim()) r.name = n.value.trim();
    s.body.querySelectorAll('[data-i]').forEach((inp) => {
      const e = r.exercises[Number(inp.dataset.i)]; if (!e) return;
      const k = inp.dataset.k; const v = inp.value.trim();
      if (k === 'sets' || k === 'rest') e[k] = Math.max(k === 'sets' ? 1 : 0, parseInt(v, 10) || (k === 'sets' ? 3 : 90));
      else if (v) e[k] = v;
    });
  };
  s.body.addEventListener('click', (e) => {
    const mv = e.target.closest('[data-mv]'); const del = e.target.closest('[data-del]'); const add = e.target.closest('[data-add]');
    if (!mv && !del && !add) return;
    read();
    if (mv) { const i = Number(mv.dataset.mv); const j = i + Number(mv.dataset.d); [r.exercises[i], r.exercises[j]] = [r.exercises[j], r.exercises[i]]; }
    if (del) r.exercises.splice(Number(del.dataset.del), 1);
    if (add) r.exercises.push({ id: uid('ex'), name: 'Nuevo ejercicio', sets: 3, reps: '8-10', rest: 90 });
    s.setBody(draw());
    if (add) { const ins = s.body.querySelectorAll('[data-k="name"]'); const last = ins[ins.length - 1]; last?.focus(); last?.select(); }
  });
  s.foot.addEventListener('click', async (e) => {
    if (e.target.closest('[data-ok]')) { read(); store.commit('rutina'); s.close(true); }
    if (e.target.closest('[data-delr]')) {
      if (!(await confirmDialog({ title: `¿Borrar ${r.name}?`, text: 'Las sesiones ya guardadas no se borran.', ok: 'Borrar', danger: true }))) return;
      store.S().gym.routines = store.routines().filter((x) => x.id !== r.id); store.commit('rutina'); s.close(true);
    }
  });
  return s.done;
}

function openSessionDetail(id) {
  const S = store.S();
  const ses = S.gym.sessions.find((x) => x.id === id);
  if (!ses) return;
  const body = (ses.exercises || []).map((e) => `<div class="top-row" style="display:block"><b>${esc(e.name)}</b><div class="muted" style="font-size:14px;margin-top:2px">${(e.sets || []).map((x) => `${fmt(x.kg, 1)} kg × ${x.reps}`).join(' · ') || 'sin series'}${e.note ? ` — ${esc(e.note)}` : ''}</div></div>`).join('');
  const s = openSheet({ title: `${ses.routineName || 'Sesión'} · ${cap(fmtDayShort(ses.date))}`, body: `<div class="top-list">${body}</div>`, footer: `<button class="btn ghost" data-del>${icon('trash', 18)} Borrar</button><button class="btn ghost" data-date>${icon('calendar', 18)} Cambiar fecha</button><button class="btn primary" data-ok>Cerrar</button>` });
  s.foot.addEventListener('click', async (e) => {
    if (e.target.closest('[data-ok]')) s.close();
    if (e.target.closest('[data-date]')) {
      const d = await pickDate({ value: ses.date, max: todayISO() });
      if (d && d !== ses.date) { ses.date = d; store.setGym(d, 'fui', ses.routineName); store.commit('gym'); s.close(); }
    }
    if (e.target.closest('[data-del]')) {
      if (!(await confirmDialog({ title: '¿Borrar la sesión?', ok: 'Borrar', danger: true }))) return;
      S.gym.sessions = S.gym.sessions.filter((x) => x.id !== id); store.commit('gym'); s.close();
    }
  });
}

async function openExerciseProgress(name0 = null) {
  const names = [...new Set(store.S().gym.sessions.flatMap((s) => (s.exercises || []).map((e) => e.name)))].sort();
  if (!names.length) return;
  const name = name0 || await pickOption({ title: 'Ejercicio', options: names.map((n) => ({ value: n, label: n, sub: `${store.exerciseHistory(n).length} sesiones` })) });
  if (!name) return;
  const pts = store.exerciseHistory(name);
  const best = pts.reduce((a, p) => Math.max(a, p.e1rm), 0);
  openSheet({
    title: name,
    body: pts.length ? `<div class="stat-grid"><div class="stat"><small>Mejor 1RM estimado</small><b>${fmt(best, 1)} kg</b></div><div class="stat"><small>Peso máximo usado</small><b>${fmt(Math.max(...pts.map((p) => p.top)), 1)} kg</b></div></div>
      <h3 class="sub-h">1RM estimado por sesión</h3><div class="chart-box">${simpleLine({ points: pts, key: 'e1rm' })}</div>
      <div class="top-list" style="margin-top:10px">${pts.slice().reverse().slice(0, 12).map((p) => `<div class="top-row"><span>${esc(cap(fmtDayShort(p.date)))}</span><span>${fmt(p.top, 1)} kg máx · 1RM ${fmt(p.e1rm, 1)}</span></div>`).join('')}</div>` : '<p class="muted">Sin datos.</p>',
  });
}

// ===========================================================================
// AJUSTES
// ===========================================================================
let settingsSheet = null;
export function openSettings(section = null) {
  if (section === 'habitos') return editHabits();
  if (section === 'ia') return openAISettings();
  if (section === 'alimentos') return openMyFoods();
  const S = store.S();
  const ai = S.settings.ai;
  const g = S.settings.goals;
  const themeL = { auto: 'Automático', light: 'Claro', dark: 'Oscuro' };
  const row = (act, ic, title, sub, val = '') => `<button class="set-row-btn" data-s="${act}">${icon(ic, 22)}<span class="grow">${title}${sub ? `<small>${sub}</small>` : ''}</span>${val ? `<span class="val">${val}</span>` : ''}${icon('right', 18)}</button>`;
  const draw = () => `
    <div class="set-group"><h3>Tus metas</h3>
      ${row('perfil', 'user', 'Perfil y metas diarias', `${fmt(g.kcal)} kcal · P ${fmt(g.p)} · C ${fmt(g.c)} · G ${fmt(g.f)} · agua ${fmt((g.waterMl || 2500) / 1000, 1)} L`)}
    </div>
    <div class="set-group"><h3>Registro con IA</h3>
      ${row('ia', 'sparkle', 'Inteligencia artificial', ai.key ? `Conectada${ai.resolvedModel ? ' · ' + esc(prettyModel(ai.resolvedModel)) : ''}${ai.web !== false ? ' · con búsqueda web' : ''}` : 'Falta tu clave de Gemini', ai.key ? '' : '<span class="bad">Configurar</span>')}
      ${row('bench', 'check', 'Probar la IA', 'Mensajes de prueba con resultados esperados (no se guardan)')}
    </div>
    <div class="set-group"><h3>Personalizar</h3>
      ${row('momentos', 'clock', 'Comidas del día', S.settings.moments.map((m) => m.name).join(', '))}
      ${row('habitos', 'pill', 'Hábitos y suplementos', S.settings.habits.map((h) => h.name).join(', '))}
      ${row('alimentos', 'library', 'Mis alimentos', `${S.customFoods.length} guardados`)}
      ${row('tema', S.settings.ui.theme === 'dark' ? 'moon' : 'sun', 'Tema', '', themeL[S.settings.ui.theme] || 'Automático')}
      ${row('vaso', 'glass', 'Tamaño del vaso', '', `${S.settings.ui.glassMl || 250} ml`)}
    </div>
    <div class="set-group"><h3>Tus datos</h3>
      ${row('excel', 'download', 'Exportar a Excel', 'Resumen, diario, comidas desplegables, gimnasio, progreso y hábitos')}
      ${row('backup', 'file', 'Copia de seguridad', S.settings.backup.lastAt ? `Última: ${relativeDayLabel(isoFromTs(S.settings.backup.lastAt)).toLowerCase()}` : 'Nunca hiciste una copia')}
      ${row('restore', 'upload', 'Restaurar copia', 'Desde un archivo .json de ApexTrack')}
      ${row('import', 'upload', 'Importar planilla anterior', 'El Excel o Google Sheets de la versión 1')}
      ${row('borrar', 'trash', 'Borrar todos los datos', '')}
    </div>
    <div class="set-group"><h3>Acerca de</h3>
      <div class="set-row-btn" style="cursor:default">${icon('info', 22)}<span class="grow">ApexTrack ${store.APP_VERSION}<small>Datos guardados solo en este teléfono (${esc(store.state.storage)}). ${store.S().entries.length} comidas registradas.</small></span></div>
    </div>`;
  const s = openSheet({ title: 'Ajustes', full: true, body: draw() });
  settingsSheet = s;
  const off = store.onChange(() => { if (!s.closed) s.setBody(draw()); });
  s.done.then(() => { off(); settingsSheet = null; });
  s.body.addEventListener('click', async (e) => {
    const b = e.target.closest('[data-s]');
    if (!b) return;
    const k = b.dataset.s;
    if (k === 'perfil') editProfile();
    else if (k === 'ia') openAISettings();
    else if (k === 'bench') openBench();
    else if (k === 'momentos') editMoments();
    else if (k === 'habitos') editHabits();
    else if (k === 'alimentos') openMyFoods();
    else if (k === 'tema') {
      const v = await pickOption({ title: 'Tema', value: S.settings.ui.theme, options: [{ value: 'auto', label: 'Automático', sub: 'Igual que el teléfono', icon: 'repeat' }, { value: 'light', label: 'Claro', icon: 'sun' }, { value: 'dark', label: 'Oscuro', icon: 'moon' }] });
      if (v) { S.settings.ui.theme = v; applyTheme(); store.commit('tema'); }
    } else if (k === 'vaso') {
      const v = await pickOption({ title: 'Tamaño del vaso', value: S.settings.ui.glassMl, options: [200, 250, 300, 350, 500].map((x) => ({ value: x, label: `${x} ml` })) });
      if (v) { S.settings.ui.glassMl = v; store.commit('vaso'); }
    } else if (k === 'excel') exportExcelFlow(b);
    else if (k === 'backup') backupFlow();
    else if (k === 'restore') restoreFlow();
    else if (k === 'import') importFlow();
    else if (k === 'borrar') wipeFlow();
  });
  return s;
}
const isoFromTs = (ts) => { const d = new Date(ts); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };

async function editProfile() {
  const S = store.S();
  const p = S.settings.profile; const g = S.settings.goals;
  const r = await formSheet({
    title: 'Perfil y metas',
    intro: `Tus macros suman ${fmt(g.p * 4 + g.c * 4 + g.f * 9)} kcal (proteína y carbos 4 kcal/g, grasas 9 kcal/g).`,
    fields: [
      { key: 'name', label: 'Nombre', type: 'text', value: p.name || '', full: true },
      { key: 'heightCm', label: 'Altura', type: 'number', suffix: 'cm', value: p.heightCm || '' },
      { key: 'goalWeight', label: 'Peso objetivo', type: 'number', suffix: 'kg', value: p.goalWeight ? String(p.goalWeight).replace('.', ',') : '' },
      { key: 'kcal', label: 'Calorías', type: 'number', suffix: 'kcal', value: g.kcal },
      { key: 'p', label: 'Proteína', type: 'number', suffix: 'g', value: g.p },
      { key: 'c', label: 'Carbohidratos', type: 'number', suffix: 'g', value: g.c },
      { key: 'f', label: 'Grasas', type: 'number', suffix: 'g', value: g.f },
      { key: 'sugarMax', label: 'Azúcares máx.', type: 'number', suffix: 'g', value: g.sugarMax || '' },
      { key: 'waterMl', label: 'Agua', type: 'number', suffix: 'ml', value: g.waterMl },
      { key: 'gymDays', label: 'Días de gym por semana', type: 'number', value: g.gymDays, full: true },
    ],
  });
  if (!r) return;
  p.name = (r.name || '').trim();
  if (r.heightCm >= 100 && r.heightCm <= 250) p.heightCm = round0(r.heightCm);
  p.goalWeight = r.goalWeight >= 25 && r.goalWeight <= 300 ? round1(r.goalWeight) : null;
  for (const k of ['kcal', 'p', 'c', 'f', 'sugarMax', 'waterMl']) if (Number.isFinite(r[k]) && r[k] >= 0) g[k] = round0(r[k]);
  if (r.gymDays >= 0 && r.gymDays <= 7) g.gymDays = round0(r.gymDays);
  const sum = g.p * 4 + g.c * 4 + g.f * 9;
  store.commit('metas');
  if (Math.abs(sum - g.kcal) > g.kcal * 0.1) toast(`Ojo: tus macros suman ${fmt(sum)} kcal y la meta es ${fmt(g.kcal)}`, { ms: 6000 });
  else toast('Metas guardadas');
}

// ---------- IA ----------
function openAISettings() {
  const S = store.S();
  const ai = S.settings.ai;
  const PREC = { rapida: 'Rápida', equilibrada: 'Equilibrada', maxima: 'Máxima precisión' };
  const draw = () => `
    <p class="muted pad-b">La IA usa Google Gemini con tu propia clave gratuita. La clave queda guardada solo en este teléfono.</p>
    <label class="field"><span>Clave de API de Gemini</span><div class="input-wrap"><input class="input" id="ai-key" type="password" autocomplete="off" spellcheck="false" placeholder="Pegá tu clave (AIza… o AQ.…)" value="${esc(ai.key)}"><em><button class="link" data-a="show" type="button">Ver</button></em></div></label>
    <p class="note">¿No tenés clave? Entrá a <a href="https://aistudio.google.com/apikey" target="_blank" rel="noopener">aistudio.google.com/apikey</a>, tocá "Create API key", copiala y pegala acá.</p>
    <div class="set-group" style="margin-top:14px">
      <button class="set-row-btn" data-a="prec">${icon('bolt', 22)}<span class="grow">Precisión<small>Máxima usa un modelo más grande: tarda más y gasta más cuota</small></span><span class="val">${PREC[ai.precision] || 'Equilibrada'}</span>${icon('right', 18)}</button>
      <button class="set-row-btn" data-a="model">${icon('sparkle', 22)}<span class="grow">Modelo<small>${ai.resolvedModel ? 'En uso: ' + esc(ai.resolvedModel) : 'Se elige solo el mejor disponible'}</small></span><span class="val">${ai.model === 'auto' || !ai.model ? 'Automático' : esc(ai.model)}</span>${icon('right', 18)}</button>
      <button class="set-row-btn" data-a="web">${icon('globe', 22)}<span class="grow">Buscar en internet<small>Para marcas, productos y comidas nuevas. Sin internet usa tu biblioteca.</small></span><span class="switch ${ai.web !== false ? 'on' : ''}" role="switch" aria-checked="${ai.web !== false}"></span></button>
    </div>
    <label class="field" style="margin-top:14px"><span>Indicaciones para la IA (opcional)</span><textarea class="input" id="ai-notes" rows="3" placeholder="Ej.: la leche que tomo es Protein de La Serenísima. Cuando digo 'un plato' de pasta son 350 g cocidos.">${esc(ai.notes || '')}</textarea></label>
    <div id="ai-status" class="status-line" ${ai.lastTest ? '' : 'hidden'}>${ai.lastTest ? esc(ai.lastTest) : ''}</div>`;
  const s = openSheet({ title: 'Inteligencia artificial', full: true, body: draw(), footer: `<button class="btn ghost" data-a="test">${icon('link', 18)} Probar conexión</button><button class="btn primary" data-a="save">Guardar</button>` });
  const readInputs = () => {
    const k = s.body.querySelector('#ai-key'); const n = s.body.querySelector('#ai-notes');
    if (k) { const nv = k.value.trim().replace(/\s+/g, ''); if (nv !== ai.key) { ai.key = nv; ai.models = []; ai.modelsAt = 0; ai.resolvedModel = ''; ai.endpoint = ''; ai.auth = ''; } }
    if (n) ai.notes = n.value;
  };
  const handler = async (e) => {
    const b = e.target.closest('[data-a]');
    if (!b) return;
    const a = b.dataset.a;
    if (a === 'show') { const k = s.body.querySelector('#ai-key'); k.type = k.type === 'password' ? 'text' : 'password'; b.textContent = k.type === 'password' ? 'Ver' : 'Ocultar'; return; }
    readInputs();
    if (a === 'prec') {
      const v = await pickOption({ title: 'Precisión', value: ai.precision, options: [{ value: 'rapida', label: 'Rápida', sub: 'Respuestas en pocos segundos' }, { value: 'equilibrada', label: 'Equilibrada', sub: 'Recomendada' }, { value: 'maxima', label: 'Máxima precisión', sub: 'Modelo Pro: más lento, menos cuota gratis' }] });
      if (v) { ai.precision = v; store.commit('ia'); s.setBody(draw()); }
    } else if (a === 'model') {
      let models = ai.models;
      if (ai.key && (!models || !models.flash)) { try { models = await AI.discoverModels(ai, { force: true }); } catch { /* sin lista */ } }
      const list = [...new Set([...(models?.flash || []), ...(models?.pro || []), ...(models?.lite || []), ...AI.FALLBACK_MODELS])].slice(0, 12);
      const v = await pickOption({ title: 'Modelo', value: ai.model || 'auto', options: [{ value: 'auto', label: 'Automático', sub: 'Recomendado: si un modelo deja de existir, usa otro' }, ...list.map((m) => ({ value: m, label: m }))] });
      if (v) { ai.model = v; store.commit('ia'); s.setBody(draw()); }
    } else if (a === 'web') { ai.web = ai.web === false; store.commit('ia'); s.setBody(draw()); }
    else if (a === 'save') { store.commit('ia'); s.close(); toast(ai.key ? 'IA configurada' : 'Guardado (sin clave, se usa la biblioteca)'); }
    else if (a === 'test') {
      if (!ai.key) { toast('Pegá primero tu clave', { kind: 'error' }); return; }
      store.commit('ia');
      const st = s.body.querySelector('#ai-status');
      setBusy(b, true, 'Probando…');
      st.hidden = false; st.innerHTML = `<span class="spin"></span> Conectando con Gemini…`;
      try {
        const r = await AI.testConnection(ai);
        ai.lastTest = `Conectada con ${r.model} en ${fmt(r.ms / 1000, 1)} s`;
        st.innerHTML = `${icon('check', 20, 'ok')} ${esc(ai.lastTest)}`;
        store.commit('ia');
      } catch (err) {
        st.innerHTML = `${icon('alert', 20, 'bad')} ${esc(err.message || 'No se pudo conectar')}`;
      } finally { setBusy(b, false); }
    }
  };
  s.body.addEventListener('click', handler);
  s.foot.addEventListener('click', handler);
  s.done.then(() => { readInputs(); store.commit('ia'); });
}

// ---------- Banco de pruebas de la IA (no guarda nada) ----------
function draftSummary(draft) {
  const groups = draft.groups.map((g) => {
    const t = AI.groupTotals(g);
    return `<div class="rv-meal" style="margin-top:8px"><div class="rv-meal-head"><b>${esc(relativeDayLabel(g.date))} · ${esc(store.momentName(g.moment))}</b><span class="right">${fmt(t.kcal)} kcal</span></div>
      ${g.items.map((it) => { const m = store.itemMacros(it); return `<div class="note" style="color:var(--ink-2)">• ${esc(it.name)} — ${esc(portion(it))} → ${fmt(m.kcal)} kcal · P ${fmt(m.p, 1)} · C ${fmt(m.c, 1)} · G ${fmt(m.f, 1)}${it.flags?.length ? ` <span class="warn">(${esc(it.flags.join(', '))})</span>` : ''}</div>`; }).join('')}</div>`;
  }).join('');
  const extras = [
    ...draft.water.map((w) => `Agua ${relativeDayLabel(w.date).toLowerCase()}: ${w.mode === 'set' ? 'total ' : '+'}${w.ml} ml`),
    ...draft.habits.map((h) => `${h.name || h.id}: ${h.done ? 'sí' : 'no'} (${relativeDayLabel(h.date).toLowerCase()})`),
    ...draft.gym.map((x) => `Gimnasio ${relativeDayLabel(x.date).toLowerCase()}: ${x.status}`),
    ...draft.weight.map((x) => `Peso: ${fmt(x.kg, 1)} kg`),
    ...draft.questions.map((q) => `Pregunta: ${q}`),
  ];
  return groups + (extras.length ? `<div class="note" style="margin-top:6px">${extras.map(esc).join(' · ')}</div>` : '');
}
const portion = (it) => `${fmt(it.qty, 2)} ${unitLabel(it.unit, it.qty)}${it.grams != null && it.unit !== 'g' && it.unit !== 'ml' ? ` (${fmt(it.grams)} ${it.liq ? 'ml' : 'g'})` : ''}`;

function openBench() {
  const ai = store.S().settings.ai;
  const results = {};
  const draw = () => `
    <p class="muted pad-b">Cada prueba manda un mensaje a la IA y compara el resultado con lo esperado (calorías, comidas, agua, hábitos). <b>No se guarda nada en tu registro.</b>${ai.key ? '' : ' <span class="bad">Primero configurá tu clave de Gemini.</span>'}</p>
    <label class="field"><span>Probar un mensaje propio</span><textarea class="input" id="bench-own" rows="3" placeholder="Escribí lo que comiste, como en un mensaje"></textarea></label>
    <div style="display:flex;gap:8px;margin:8px 0 4px"><button class="btn small" data-b="own">${icon('send', 16)} Analizar sin guardar</button><button class="btn small ghost" data-b="own-off">${icon('wifioff', 16)} Sin IA</button></div>
    <div id="bench-own-out"></div>
    <h3 class="sub-h">Pruebas incluidas (${AI.TEST_CASES.length})</h3>
    ${AI.TEST_CASES.map((tc) => {
      const r = results[tc.id];
      return `<div class="test-row" data-tc="${tc.id}">
        <h5>${r ? (r.running ? '<span class="spin"></span>' : r.error ? icon('alert', 18, 'bad') : r.ev.pass ? icon('check', 18, 'ok') : icon('x', 18, 'bad')) : icon('info', 18)}${esc(tc.title)}</h5>
        <div class="note">“${esc(tc.text.length > 150 ? tc.text.slice(0, 150) + '…' : tc.text)}”</div>
        ${r && !r.running ? (r.error ? `<p class="note bad">${esc(r.error)}</p>` : `<ul>${r.ev.checks.map((c) => `<li class="${c.ok ? '' : 'no'}">${c.ok ? '✓' : '✗'} ${esc(c.msg)}</li>`).join('')}</ul><details><summary class="note">Ver detalle (${r.ms ? fmt(r.ms / 1000, 1) + ' s' : ''}${r.model ? ' · ' + esc(r.model) : ''})</summary>${draftSummary(r.draft)}</details>`) : ''}
        <div style="margin-top:6px"><button class="btn small ghost" data-b="one" data-id="${tc.id}">${r && !r.running ? 'Repetir' : 'Probar'}</button></div>
      </div>`;
    }).join('')}`;
  const s = openSheet({ title: 'Probar la IA', full: true, body: draw(), footer: `<button class="btn ghost" data-b="copy">${icon('copy', 18)} Copiar informe</button><button class="btn primary" data-b="all">${icon('play', 18)} Probar todas</button>` });
  const runOne = async (tc) => {
    results[tc.id] = { running: true }; s.setBody(draw());
    const ctx = AI.testContext(tc);
    const t0 = Date.now();
    try {
      const draft = await AI.analyze({ text: tc.text, ctx });
      results[tc.id] = { draft, ev: AI.evaluateDraft(draft, tc, ctx), ms: Date.now() - t0, model: draft.meta?.model || '' };
    } catch (err) { results[tc.id] = { error: err.message || String(err) }; }
    if (!s.closed) s.setBody(draw());
  };
  const handler = async (e) => {
    const b = e.target.closest('[data-b]');
    if (!b) return;
    const k = b.dataset.b;
    if (k === 'one') runOne(AI.TEST_CASES.find((x) => x.id === b.dataset.id));
    else if (k === 'all') {
      if (!ai.key) { toast('Configurá tu clave de Gemini primero', { kind: 'error', action: 'Configurar', onAction: openAISettings }); return; }
      setBusy(b, true, 'Probando…');
      for (const tc of AI.TEST_CASES) { if (s.closed) break; await runOne(tc); }
      setBusy(b, false);
      const ok = Object.values(results).filter((r) => r.ev?.pass).length;
      toast(`${ok} de ${AI.TEST_CASES.length} pruebas correctas`);
    } else if (k === 'copy') {
      const rep = AI.TEST_CASES.map((tc) => {
        const r = results[tc.id];
        if (!r || r.running) return `${tc.id}: sin probar`;
        if (r.error) return `${tc.id}: ERROR ${r.error}`;
        return `${tc.id}: ${r.ev.pass ? 'OK' : 'FALLA'} (${r.model}, ${fmt(r.ms / 1000, 1)} s)\n  ${r.ev.checks.map((c) => (c.ok ? '✓ ' : '✗ ') + c.msg).join('\n  ')}\n  ${r.draft.groups.map((g) => `${g.date} ${g.moment}: ${g.items.map((it) => `${it.name} ${portion(it)} = ${store.itemMacros(it).kcal} kcal`).join('; ')}`).join('\n  ')}`;
      }).join('\n');
      try { await navigator.clipboard.writeText(`Informe de pruebas ApexTrack ${store.APP_VERSION}\n${rep}`); toast('Informe copiado: pegalo en el chat'); } catch { toast('No se pudo copiar', { kind: 'error' }); }
    } else if (k === 'own' || k === 'own-off') {
      const txt = s.body.querySelector('#bench-own').value.trim();
      const out = s.body.querySelector('#bench-own-out');
      if (!txt) return;
      if (k === 'own') {
        if (!ai.key) { toast('Configurá tu clave de Gemini primero', { kind: 'error' }); return; }
        setBusy(b, true, 'Analizando…');
        try { const d = await AI.analyze({ text: txt }); out.innerHTML = `<div class="panel" style="margin-top:8px">${draftSummary(d)}<p class="note">Total: ${fmt(AI.draftTotals(d).kcal)} kcal · ${esc(prettyModel(d.meta?.model))}${d.meta?.web ? ' · con búsqueda web' : ''}</p></div>`; } catch (err) { out.innerHTML = `<p class="note bad">${esc(err.message)}</p>`; }
        setBusy(b, false);
      } else {
        const d = AI.analyzeOffline(txt, {});
        out.innerHTML = `<div class="panel" style="margin-top:8px">${draftSummary(d)}<p class="note">Total: ${fmt(AI.draftTotals(d).kcal)} kcal · cálculo sin IA</p></div>`;
      }
    }
  };
  s.body.addEventListener('click', handler);
  s.foot.addEventListener('click', handler);
}

// ---------- Momentos ----------
function editMoments() {
  const S = store.S();
  const draw = () => `<p class="muted pad-b">Renombrá, ordená o agregá comidas. La IA las reconoce por nombre.</p><div class="edit-list">${S.settings.moments.map((m, i) => `
    <div class="er"><button class="grow opt" style="border:0;padding:6px 0;min-height:44px" data-ren="${i}"><span class="opt-main"><span>${esc(m.name)}${m.h ? `<small>${fmtH(m.h[0])} a ${fmtH(m.h[1])}</small>` : '<small>sin horario</small>'}</span></span></button>
      <button class="icon-btn" data-mv="${i}" data-d="-1" aria-label="Subir" ${i === 0 ? 'disabled' : ''}>${icon('up', 18)}</button>
      <button class="icon-btn" data-mv="${i}" data-d="1" aria-label="Bajar" ${i === S.settings.moments.length - 1 ? 'disabled' : ''}>${icon('down', 18)}</button>
      <button class="icon-btn" data-del="${i}" aria-label="Quitar">${icon('trash', 18)}</button></div>`).join('')}</div>
    <button class="btn ghost" style="width:100%;margin-top:12px" data-add>${icon('plus', 18)} Agregar comida</button>
    <button class="btn ghost" style="width:100%;margin-top:8px" data-reset>${icon('undo', 18)} Volver a las predeterminadas</button>`;
  const s = openSheet({ title: 'Comidas del día', full: true, body: draw() });
  s.body.addEventListener('click', async (e) => {
    const L = S.settings.moments;
    const ren = e.target.closest('[data-ren]'); const mv = e.target.closest('[data-mv]'); const del = e.target.closest('[data-del]');
    if (ren) {
      const m = L[Number(ren.dataset.ren)];
      const r = await formSheet({ title: m.name, intro: 'El horario se usa para proponer la comida cuando registrás sin decir cuál es. Dejalo vacío si no tiene horario fijo.', fields: [
        { key: 'name', label: 'Nombre', type: 'text', value: m.name, full: true },
        { key: 'a', label: 'Desde', type: 'text', value: m.h ? fmtH(m.h[0]) : '', placeholder: '12:00' },
        { key: 'b', label: 'Hasta', type: 'text', value: m.h ? fmtH(m.h[1]) : '', placeholder: '15:30' },
      ] });
      if (!r) return;
      if (r.name.trim()) m.name = r.name.trim();
      const a = parseH(r.a); const b = parseH(r.b);
      if (a != null && b != null && a !== b) m.h = [a, b];
      else if (!r.a.trim() && !r.b.trim()) m.h = null;
      else toast('Horario no válido: usá el formato 12:30', { kind: 'error' });
      store.commit('momentos'); s.setBody(draw());
    } else if (mv) { const i = Number(mv.dataset.mv); const j = i + Number(mv.dataset.d); [L[i], L[j]] = [L[j], L[i]]; store.commit('momentos'); s.setBody(draw()); }
    else if (del) {
      const m = L[Number(del.dataset.del)];
      const used = S.entries.filter((x) => x.moment === m.id).length;
      if (L.length <= 1) return;
      if (!(await confirmDialog({ title: `¿Quitar ${m.name}?`, text: used ? `Tiene ${used} registros: quedan guardados, pero no vas a poder elegir esta comida.` : '', ok: 'Quitar', danger: true }))) return;
      L.splice(Number(del.dataset.del), 1); store.commit('momentos'); s.setBody(draw());
    } else if (e.target.closest('[data-add]')) {
      const v = await promptText({ title: 'Nueva comida', label: 'Nombre', placeholder: 'Ej.: Colación' });
      if (v) { L.push({ id: slug(v) || uid('m'), name: v, h: null }); store.commit('momentos'); s.setBody(draw()); }
    } else if (e.target.closest('[data-reset]')) {
      if (!(await confirmDialog({ title: '¿Volver a las comidas predeterminadas?', ok: 'Restablecer' }))) return;
      S.settings.moments = deepClone(store.DEFAULT_MOMENTS); store.commit('momentos'); s.setBody(draw());
    }
  });
}
const fmtRest = (x) => (x < 60 ? `${x} s` : `${Math.floor(x / 60)}:${String(x % 60).padStart(2, '0')} min`);
const parseH = (t) => { const m = String(t || '').trim().match(/^(\d{1,2})(?:[:.,h](\d{2}))?$/); if (!m) return null; const h = Number(m[1]) + (m[2] ? Number(m[2]) / 60 : 0); return h >= 0 && h <= 24 ? h : null; };
const fmtH = (h) => `${Math.floor(h)}:${String(Math.round((h % 1) * 60)).padStart(2, '0')}`;

// ---------- Hábitos ----------
function editHabits() {
  const S = store.S();
  const KIND = { supp: 'Suplemento', habit: 'Hábito', hours: 'Horas' };
  const draw = () => `<p class="muted pad-b">Los hábitos se marcan en Hoy con un toque, o diciéndoselo a la IA ("tomé la creatina").</p><div class="edit-list">${S.settings.habits.map((h, i) => `
    <div class="er"><button class="grow opt" style="border:0;padding:6px 0;min-height:44px" data-ed="${i}"><span class="opt-main">${icon(h.kind === 'supp' ? 'pill' : h.kind === 'hours' ? 'book' : 'star', 20)}<span>${esc(h.name)}<small>${KIND[h.kind] || 'Hábito'}${h.detail ? ' · ' + esc(h.detail) : ''}</small></span></span></button>
      <button class="icon-btn" data-mv="${i}" data-d="-1" aria-label="Subir" ${i === 0 ? 'disabled' : ''}>${icon('up', 18)}</button>
      <button class="icon-btn" data-mv="${i}" data-d="1" aria-label="Bajar" ${i === S.settings.habits.length - 1 ? 'disabled' : ''}>${icon('down', 18)}</button>
      <button class="icon-btn" data-del="${i}" aria-label="Quitar">${icon('trash', 18)}</button></div>`).join('')}</div>
    <button class="btn ghost" style="width:100%;margin-top:12px" data-add>${icon('plus', 18)} Agregar hábito o suplemento</button>`;
  const s = openSheet({ title: 'Hábitos y suplementos', full: true, body: draw() });
  const edit = async (h) => {
    const r = await formSheet({ title: h.name ? 'Editar' : 'Nuevo hábito', fields: [
      { key: 'name', label: 'Nombre', type: 'text', value: h.name || '', full: true },
      { key: 'detail', label: 'Detalle (dosis, etc.)', type: 'text', value: h.detail || '', full: true },
      { key: 'aliases', label: 'Otras formas de decirlo (separadas por coma)', type: 'text', value: (h.aliases || []).join(', '), full: true },
    ] });
    if (!r || !r.name.trim()) return false;
    const kind = await pickOption({ title: 'Tipo', value: h.kind || 'habit', options: [{ value: 'supp', label: 'Suplemento', icon: 'pill' }, { value: 'habit', label: 'Hábito (sí o no)', icon: 'star' }, { value: 'hours', label: 'Horas (ej.: estudio)', icon: 'book' }] });
    h.name = r.name.trim(); h.detail = r.detail.trim(); h.kind = kind || h.kind || 'habit';
    h.aliases = r.aliases.split(',').map((x) => x.trim().toLowerCase()).filter(Boolean);
    if (!h.aliases.includes(norm(h.name))) h.aliases.unshift(norm(h.name));
    return true;
  };
  s.body.addEventListener('click', async (e) => {
    const L = S.settings.habits;
    const ed = e.target.closest('[data-ed]'); const mv = e.target.closest('[data-mv]'); const del = e.target.closest('[data-del]');
    if (ed) { if (await edit(L[Number(ed.dataset.ed)])) { store.commit('habitos'); s.setBody(draw()); } }
    else if (mv) { const i = Number(mv.dataset.mv); const j = i + Number(mv.dataset.d); [L[i], L[j]] = [L[j], L[i]]; store.commit('habitos'); s.setBody(draw()); }
    else if (del) {
      const h = L[Number(del.dataset.del)];
      if (!(await confirmDialog({ title: `¿Quitar ${h.name}?`, text: 'Lo que ya marcaste queda en el historial.', ok: 'Quitar', danger: true }))) return;
      L.splice(Number(del.dataset.del), 1); store.commit('habitos'); s.setBody(draw());
    } else if (e.target.closest('[data-add]')) {
      const h = { id: '', name: '', kind: 'habit', aliases: [] };
      if (await edit(h)) {
        if (h.kind === 'hours' && L.some((x) => x.kind === 'hours')) { toast('Ya tenés un hábito de horas; se guarda como hábito sí/no'); h.kind = 'habit'; }
        let id = slug(h.name); while (L.some((x) => x.id === id)) id += '_2';
        h.id = id; L.push(h); store.commit('habitos'); s.setBody(draw());
      }
    }
  });
}

// ---------- Mis alimentos ----------
function openMyFoods() {
  const S = store.S();
  let q = '';
  const draw = () => {
    const list = S.customFoods.filter((f) => !q || norm(f.n).includes(norm(q))).sort((a, b) => a.n.localeCompare(b.n));
    return `<p class="muted pad-b">Alimentos y recetas propias. La IA los usa cuando los nombrás igual. Se agregan desde el editor de cualquier alimento ("Guardar en Mis alimentos").</p>
      <div class="input-wrap" style="margin-bottom:10px"><input class="input" id="mf-q" placeholder="Buscar" value="${esc(q)}" autocomplete="off"></div>
      <div class="opt-list">${list.map((f) => `<button class="opt" data-id="${f.id}"><span class="opt-main"><span>${esc(f.n)}<small>${fmt(f.k)} kcal · P ${fmt(f.p, 1)} · C ${fmt(f.c, 1)} · G ${fmt(f.f, 1)} cada 100 ${f.liq ? 'ml' : 'g'}${Object.keys(f.u || {}).length ? ' · ' + Object.entries(f.u).map(([u, g]) => `1 ${unitLabel(u)} = ${fmt(g)} ${f.liq ? 'ml' : 'g'}`).join(', ') : ''}</small></span></span>${icon('right', 18)}</button>`).join('') || '<div class="empty"><strong>Sin alimentos propios</strong>Creá uno con el botón de abajo.</div>'}</div>`;
  };
  const s = openSheet({ title: 'Mis alimentos', full: true, body: draw(), footer: `<button class="btn primary" data-new>${icon('plus', 18)} Nuevo alimento</button>` });
  s.body.addEventListener('input', (e) => { if (e.target.id === 'mf-q') { q = e.target.value; const pos = e.target.selectionStart; s.setBody(draw()); const i = s.body.querySelector('#mf-q'); i.focus(); i.setSelectionRange(pos, pos); } });
  s.body.addEventListener('click', async (e) => { const b = e.target.closest('[data-id]'); if (b && await editFood(S.customFoods.find((f) => f.id === b.dataset.id))) s.setBody(draw()); });
  s.foot.addEventListener('click', async (e) => { if (e.target.closest('[data-new]') && await editFood(null)) s.setBody(draw()); });
}

async function editFood(f) {
  const isNew = !f;
  f = f || { n: '', k: '', p: '', c: '', f: '', s: 0, fb: 0, u: {} };
  const unitsTxt = Object.entries(f.u || {}).map(([u, g]) => `${unitLabel(u)}=${g}`).join(', ');
  const r = await formSheet({
    title: isNew ? 'Nuevo alimento' : 'Editar alimento', intro: 'Valores cada 100 g (o 100 ml). Los encontrás en la tabla nutricional del envase.',
    fields: [
      { key: 'n', label: 'Nombre', type: 'text', value: f.n, full: true },
      { key: 'k', label: 'Calorías', type: 'number', suffix: 'kcal', value: f.k },
      { key: 'p', label: 'Proteínas', type: 'number', suffix: 'g', value: f.p },
      { key: 'c', label: 'Carbohidratos', type: 'number', suffix: 'g', value: f.c },
      { key: 'f', label: 'Grasas', type: 'number', suffix: 'g', value: f.f },
      { key: 's', label: 'Azúcares', type: 'number', suffix: 'g', value: f.s || 0 },
      { key: 'fb', label: 'Fibra', type: 'number', suffix: 'g', value: f.fb || 0 },
      { key: 'u', label: 'Medidas (ej.: unidad=42, porción=120)', type: 'text', value: unitsTxt, full: true },
      { key: 'a', label: 'Otros nombres (separados por coma)', type: 'text', value: (f.a || []).join(', '), full: true },
    ],
    extraFooter: isNew ? '' : `<button class="btn ghost" data-r="del">${icon('trash', 18)}</button>`,
  });
  if (!r) return false;
  if (r === 'del') return false;
  if (!r.n.trim() || !Number.isFinite(r.k)) { toast('Completá al menos el nombre y las calorías', { kind: 'error' }); return false; }
  const u = {};
  for (const part of String(r.u || '').split(',')) {
    const m = part.split('=');
    if (m.length !== 2) continue;
    const unit = canonUnit(m[0].trim()); const g = parseNum(m[1]);
    if (unit && unit !== 'g' && unit !== 'ml' && g > 0) u[unit] = g;
  }
  store.saveCustomFood({ ...f, n: r.n.trim(), k: r.k, p: r.p || 0, c: r.c || 0, f: r.f || 0, s: r.s || 0, fb: r.fb || 0, u, a: String(r.a || '').split(',').map((x) => x.trim()).filter(Boolean) });
  store.commit('alimento');
  toast('Alimento guardado');
  return true;
}
// el botón de borrar del formulario de alimento
document.addEventListener('click', async (e) => {
  const b = e.target.closest('.sheet-foot [data-r="del"]');
  if (!b) return;
  e.stopPropagation();
  const title = b.closest('.sheet').querySelector('[data-k="n"]')?.value || '';
  const f = store.S().customFoods.find((x) => x.n === title);
  if (!f) return;
  if (!(await confirmDialog({ title: `¿Borrar ${f.n}?`, ok: 'Borrar', danger: true }))) return;
  store.deleteCustomFood(f.id); store.commit('alimento');
  b.closest('.sheet').querySelector('[data-r="0"]')?.click();
}, true);

// ---------- Datos ----------
async function exportExcelFlow(btn) {
  const v = await pickOption({ title: 'Exportar a Excel', options: [{ value: 'todo', label: 'Todo el historial', icon: 'list' }, { value: '30', label: 'Últimos 30 días', icon: 'calendar' }, { value: 'mes', label: 'Este mes', icon: 'calendar' }, { value: 'rango', label: 'Elegir fechas…', icon: 'calendar' }] });
  if (!v) return;
  const today = todayISO();
  let from = null; let to = null;
  if (v === '30') from = addDays(today, -29);
  else if (v === 'mes') from = monthStart(today);
  else if (v === 'rango') {
    from = await pickDate({ title: 'Desde', value: addDays(today, -30), max: today }); if (!from) return;
    to = await pickDate({ title: 'Hasta', value: today, max: today }); if (!to) return;
    if (to < from) [from, to] = [to, from];
  }
  toast('Generando el Excel…', { ms: 8000 });
  try {
    const X = await import('./excel.js');
    const r = await X.exportExcel({ from, to });
    toast(r === 'cancelado' ? 'Exportación cancelada' : 'Excel listo');
  } catch (err) { console.error(err); toast('No se pudo generar el Excel: ' + (err.message || err), { kind: 'error', ms: 6000 }); }
}

async function backupFlow() {
  try { const X = await import('./excel.js'); const r = await X.exportBackup(); toast(r === 'cancelado' ? 'Cancelado' : 'Copia de seguridad lista. Guardala en Drive o en tu PC.', { ms: 5000 }); } catch (err) { toast('No se pudo crear la copia: ' + err.message, { kind: 'error' }); }
}

function pickFile(accept) {
  return new Promise((resolve) => {
    const inp = document.createElement('input');
    inp.type = 'file'; inp.accept = accept; inp.style.display = 'none';
    document.body.appendChild(inp);
    inp.onchange = () => { const f = inp.files && inp.files[0]; inp.remove(); resolve(f || null); };
    inp.click();
  });
}

async function restoreFlow() {
  const f = await pickFile('application/json,.json');
  if (!f) return;
  try {
    const X = await import('./excel.js');
    const data = await X.readBackup(f);
    const n = data.entries.length;
    if (!(await confirmDialog({ title: '¿Restaurar esta copia?', text: `Tiene ${n} comidas registradas. Reemplaza todo lo que hay ahora en la app (tu clave de IA se mantiene).`, ok: 'Restaurar', danger: true }))) return;
    const key = store.S().settings.ai.key;
    store.replaceAll(data);
    if (!store.S().settings.ai.key) store.S().settings.ai.key = key;
    store.commit('restore'); applyTheme();
    toast('Copia restaurada');
  } catch (err) { toast(err.message || 'Archivo no válido', { kind: 'error' }); }
}

async function importFlow() {
  const f = await pickFile('.xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  if (!f) return;
  toast('Leyendo la planilla…', { ms: 8000 });
  try {
    const X = await import('./excel.js');
    const imp = await X.parseOldWorkbook(f);
    if (!imp.counts.items && !imp.counts.days) { toast('No encontré datos de ApexTrack en ese archivo', { kind: 'error' }); return; }
    const dates = [...new Set(imp.entries.map((e) => e.date))].sort();
    const overlap = dates.filter((d) => store.entriesOn(d).length).length;
    const ok = await confirmDialog({
      title: 'Importar planilla',
      text: `Encontré ${imp.counts.items} alimentos en ${dates.length} días${dates.length ? ` (${dates[0].split('-').reverse().join('/')} al ${dates[dates.length - 1].split('-').reverse().join('/')})` : ''}, ${imp.body.length} pesajes y ${imp.sessions.length} sesiones de gimnasio.${overlap ? ` ${overlap} de esos días ya tienen comidas en la app: se reemplazan por los de la planilla.` : ''}`,
      ok: 'Importar',
    });
    if (!ok) return;
    X.applyImport(imp);
    toast(`Importado: ${imp.counts.items} alimentos`);
  } catch (err) { console.error(err); toast('No se pudo leer la planilla: ' + (err.message || err), { kind: 'error', ms: 6000 }); }
}

async function wipeFlow() {
  if (!(await confirmDialog({ title: '¿Borrar todos los datos?', text: 'Se eliminan comidas, pesos, gimnasio, hábitos y ajustes de este teléfono. Te recomiendo hacer antes una copia de seguridad.', ok: 'Continuar', danger: true }))) return;
  const v = await promptText({ title: 'Confirmación', label: 'Escribí BORRAR para confirmar' });
  if (!v || v.trim().toUpperCase() !== 'BORRAR') { toast('No se borró nada'); return; }
  const key = store.S().settings.ai.key;
  store.resetAll();
  store.S().settings.ai.key = key;
  store.commit('reset'); applyTheme();
  toast('Datos borrados');
}

let reminded = false;
export function maybeBackupReminder() {
  if (reminded) return;
  reminded = true;
  const S = store.S();
  const n = S.entries.length;
  const last = S.settings.backup.lastAt || 0;
  if (n < 15 || Date.now() - last < 14 * 86400000) return;
  setTimeout(() => toast(last ? 'Hace más de 2 semanas que no hacés una copia de seguridad' : 'Tus datos viven en este teléfono: hacé una copia de seguridad', { action: 'Hacer copia', onAction: backupFlow, ms: 9000 }), 4000);
}

// ===========================================================================
// Gráficos: tocar una barra selecciona el día
// ===========================================================================
export function wireCharts(root) {
  root.querySelectorAll('.chart .hit[data-date]').forEach((h) => {
    h.setAttribute('data-act', 'chart-sel');
    h.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); h.dispatchEvent(new MouseEvent('click', { bubbles: true })); } });
  });
}

// deslizar el gráfico semanal del Diario
(function diarySwipe() {
  let x0 = null; let y0 = null;
  document.addEventListener('pointerdown', (e) => { if (!e.target.closest?.('[data-swipe="diary"]')) return; x0 = e.clientX; y0 = e.clientY; }, { passive: true });
  document.addEventListener('pointerup', (e) => {
    if (x0 == null) return;
    const dx = e.clientX - x0; const dy = e.clientY - y0; x0 = null;
    if (Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy) * 1.5) moveWeek(dx < 0 ? 1 : -1);
  }, { passive: true });
})();
function moveWeek(d) {
  const nw = addDays(ui.diary.week, 7 * d);
  if (nw > todayISO()) return;
  ui.diary.week = nw; render();
}

// ===========================================================================
// Acciones (se suman a las de app.js)
// ===========================================================================
export const moreActions = {
  'dia-mode': (el) => { ui.diary.mode = el.dataset.v; render(); },
  'dia-metric': (el) => { ui.diary.metric = el.dataset.v; render(); },
  'dia-week': (el) => moveWeek(Number(el.dataset.d)),
  'dia-month': (el) => { const nm = addMonths(monthStart(ui.diary.month), Number(el.dataset.d)); if (nm <= todayISO()) { ui.diary.month = nm; render(); } },
  'dia-pick': async () => { const d = await pickDate({ title: 'Ir a la semana de…', value: ui.diary.sel, marks: dayMarks, max: todayISO() }); if (d) { ui.diary.week = weekStart(d); ui.diary.sel = d; render(); } },
  'dia-open': (el) => { const d = el.dataset.date; if (!d || d > todayISO()) return; ui.diary.sel = d; ui.tab = 'hoy'; history.replaceState({ tab: 'hoy' }, ''); setDate(d); window.scrollTo(0, 0); },
  'chart-sel': (el) => { const d = el.dataset.date; if (d > todayISO()) return; if (ui.diary.sel === d && store.entriesOn(d).length) { moreActions['dia-open'](el); return; } ui.diary.sel = d; vibrate(6); render(); },
  'prog-range': (el) => { ui.prog.range = el.dataset.v === 'todo' ? 'todo' : Number(el.dataset.v); render(); },
  'weight-today': () => weightFor(todayISO()),
  'measures': () => openMeasures(),
  'gym-start': async (el) => { const r = store.routines().find((x) => x.id === el.dataset.id); if (r) startSession(r); },
  'gym-start-free': () => startSession(null),
  'gym-routines': () => openRoutines(),
  'gym-session': (el) => openSessionDetail(el.dataset.id),
  'gym-progress': () => openExerciseProgress(),
  'gym-cancel': async () => { if (await confirmDialog({ title: '¿Descartar la sesión?', text: 'No se guarda nada de esta sesión.', ok: 'Descartar', danger: true })) { store.S().gym.active = null; stopRest(); store.commit('gym'); } },
  'gym-finish': () => finishSession(),
  'set-done': (el) => {
    const A = store.S().gym.active; if (!A) return;
    const ex = A.exercises[Number(el.dataset.ex)]; const st = ex?.sets[Number(el.dataset.set)]; if (!st) return;
    if (!st.done) {
      const last = store.lastSetsFor(ex.name, A.date)?.sets[Number(el.dataset.set)];
      if ((st.kg === '' || st.kg == null) && last) st.kg = last.kg;
      if ((st.reps === '' || st.reps == null) && last) st.reps = last.reps;
      if (st.reps === '' || st.reps == null) { toast('Anotá las repeticiones de la serie'); return; }
    }
    st.done = !st.done; vibrate(st.done ? 20 : 8);
    if (st.done) startRest(ex.rest || 90, ex.name);
    store.commit('gym');
  },
  'set-add': (el) => { const A = store.S().gym.active; const ex = A?.exercises[Number(el.dataset.ex)]; if (!ex) return; const p = ex.sets[ex.sets.length - 1]; ex.sets.push({ kg: p ? p.kg : '', reps: '', done: false }); store.commit('gym'); },
  'ex-add': async () => {
    const A = store.S().gym.active; if (!A) return;
    const known = [...new Set([...store.routines().flatMap((r) => r.exercises.map((e) => e.name)), ...store.S().gym.sessions.flatMap((s) => (s.exercises || []).map((e) => e.name))])].sort();
    const v = await pickOption({ title: 'Agregar ejercicio', options: known.map((n) => ({ value: n, label: n })), allowCustom: true, customLabel: 'Otro ejercicio…' });
    if (!v) return;
    const name = typeof v === 'object' ? v.custom : v;
    const last = store.lastSetsFor(name, A.date);
    A.exercises.push({ name, target: '', rest: 90, sets: Array.from({ length: Math.max(3, last?.sets.length || 0) }, (_, i) => ({ kg: last?.sets[i]?.kg ?? '', reps: '', done: false })) });
    store.commit('gym');
  },
  'ex-menu': async (el) => {
    const A = store.S().gym.active; const i = Number(el.dataset.ex); const ex = A?.exercises[i]; if (!ex) return;
    const v = await pickOption({ title: ex.name, options: [
      { value: 'del-set', label: 'Quitar la última serie', icon: 'minus' },
      { value: 'rest', label: `Descanso: ${fmtRest(ex.rest || 90)}`, icon: 'timer' },
      { value: 'note', label: ex.note ? `Nota: ${ex.note}` : 'Agregar nota', icon: 'edit' },
      { value: 'prog', label: 'Ver progreso', icon: 'chart' },
      { value: 'up', label: 'Mover arriba', icon: 'up' },
      { value: 'del', label: 'Quitar ejercicio', icon: 'trash' },
    ] });
    if (v === 'del-set' && ex.sets.length > 1) ex.sets.pop();
    else if (v === 'rest') { const r = await pickOption({ title: 'Descanso', value: ex.rest || 90, options: [45, 60, 90, 120, 150, 180, 240].map((x) => ({ value: x, label: fmtRest(x) })) }); if (r) ex.rest = r; }
    else if (v === 'note') { const n = await promptText({ title: 'Nota', value: ex.note || '', label: ex.name }); if (n != null) ex.note = n; }
    else if (v === 'prog') { openExerciseProgress(ex.name); return; }
    else if (v === 'up' && i > 0) [A.exercises[i - 1], A.exercises[i]] = [A.exercises[i], A.exercises[i - 1]];
    else if (v === 'del') { if (!(await confirmDialog({ title: `¿Quitar ${ex.name}?`, ok: 'Quitar', danger: true }))) return; A.exercises.splice(i, 1); }
    else return;
    store.commit('gym');
  },
};

async function weightFor(date) {
  const b = store.bodyOn(date);
  const last = store.latestWeight();
  const v = await promptText({ title: `Peso · ${relativeDayLabel(date).toLowerCase()}`, label: 'Peso en ayunas', value: b?.weight ? String(b.weight).replace('.', ',') : '', placeholder: last ? String(last.kg).replace('.', ',') : '60,0', inputmode: 'decimal', suffix: 'kg' });
  if (v == null || v.trim() === '') return;
  const kg = parseNum(v);
  if (!(kg >= 25 && kg <= 300)) { toast('Ingresá un peso válido en kg', { kind: 'error' }); return; }
  store.upsertBody(date, { weight: round1(kg) }); store.commit('peso');
}
